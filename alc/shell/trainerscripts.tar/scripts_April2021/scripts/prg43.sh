#!/bin/bash
#Print  Natural numbers
echo "Ener the upper limit"
read limit

#print now
seq -s " " 1 $limit

#End
