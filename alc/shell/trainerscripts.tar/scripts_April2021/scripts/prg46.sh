#!/bin/bash
#Function declaration
function printme() {
echo Helo $1
}
#End of function definition
#Script begins here
printme Madhavi
printme Santhosh
#End of script
