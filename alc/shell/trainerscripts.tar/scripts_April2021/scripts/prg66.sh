#!/bin/bash
select os in unix linux aix solaris ubuntu
do
 echo $os
done
