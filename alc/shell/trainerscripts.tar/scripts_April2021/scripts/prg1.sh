#! /bin/bash
#This is my first shell script
echo "This is my first program"
echo "Enter a value"
read x
echo "The given value is $x"
#End of the script
