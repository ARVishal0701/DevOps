#!/bin/bash
#Demonstrate postional parameters
echo "You have entered $# number of positional parameters"
echo "The program name is $0"
echo "The positional parameters are $@"
echo "The positional prameters are $*"
echo "The first parameter is $1"
#End
