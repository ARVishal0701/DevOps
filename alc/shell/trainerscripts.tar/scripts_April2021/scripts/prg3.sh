#!/bin/bash
kernel=`uname -r`
os=`uname`
user=$USER
wd=$PWD

echo "kernel version is $kernel Operating system is $os login name is $user and my pwd is $wd"
#End
