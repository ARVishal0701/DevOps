#!/bin/bash
c=0
for i in `ls`
do
  ((c ++))
done
echo "There are $c file in this current directory"
#End
   
