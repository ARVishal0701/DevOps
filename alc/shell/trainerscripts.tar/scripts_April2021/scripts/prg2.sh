#! /bin/bash
#This is my first shell script
echo "This is my first program"
read -p "Enter a username:" x
echo "The given value is $x"
read -sp "Enter password:" pass
echo -e "\nThe given password is: $pass"
#End of the script
